<!DOCTYPE html>
<html>
<head>
    <title>Database Data Display and Insert</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        form {
            margin-top: 20px;
        }
        form label, form input {
            display: block;
            margin-bottom: 10px;
        }
        form button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Database Data Display and Insert</h1>

    <?php
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $dbname = 'ccit';

    $connection = mysqli_connect($dbhost, $dbuser, $dbpass);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $db_selected = mysqli_select_db($connection, $dbname);

    if (!$db_selected) {
        die("Database selection failed: " . mysqli_error($connection));
    }

    // Insert data
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $insert_name = $_POST["insert_name"];
        $insert_email = $_POST["insert_email"];
        $insert_message = $_POST["insert_message"];

        $insert_query = "INSERT INTO contact_messages (name, email, message) VALUES ('$insert_name', '$insert_email', '$insert_message')";

        if (mysqli_query($connection, $insert_query)) {
            echo "<p>Data inserted successfully!</p>";
        } else {
            echo "<p>Error inserting data: " . mysqli_error($connection) . "</p>";
        }
    }

    // Delete data
    if (isset($_GET['delete'])) {
        $delete_id = $_GET['delete'];
        $delete_query = "DELETE FROM contact_messages WHERE id = $delete_id";

        if (mysqli_query($connection, $delete_query)) {
            echo "<p>Data deleted successfully!</p>";
        } else {
            echo "<p>Error deleting data: " . mysqli_error($connection) . "</p>";
        }
    }

    $query = "SELECT * FROM contact_messages";
    $result = mysqli_query($connection, $query);
    ?>

    <h2>Displaying Data</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Action</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$row['name']}</td>";
            echo "<td>{$row['email']}</td>";
            echo "<td>{$row['message']}</td>";
            echo "<td><a href='?delete={$row['id']}'>Delete</a></td>";
            echo "</tr>";
        }
        ?>

    </table>

    <h2>Insert Data</h2>
    <form method="POST" action="">
        <label for="insert_name">Name:</label>
        <input type="text" id="insert_name" name="insert_name" required>
        
        <label for="insert_email">Email:</label>
        <input type="email" id="insert_email" name="insert_email" required>
        
        <label for="insert_message">Message:</label>
        <textarea id="insert_message" name="insert_message" rows="4" required></textarea>
        
        <button type="submit">Insert</button>
    </form>

    <?php
    mysqli_close($connection);
    ?>
</body>
</html>