<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "ccit";

// Create a database connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$signupSuccess = false;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup_username"]) && isset($_POST["signup_password"])) {
    $username = $_POST["signup_username"];
    $password = $_POST["signup_password"];

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashedPassword')";
    if ($conn->query($sql) === TRUE) {
        $signupSuccess = true;

        // Set a cookie for the username
        setcookie("username", $username, time() + 3600, "/");

        header("Location: welcome.php?message=Welcome, $username!");
    } else {
        $signupError = "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Sign Up</h2>
        <?php if ($signupSuccess) : ?>
            <p class="success">Sign up successful! You are now signed in.</p>
        <?php elseif (isset($signupError)) : ?>
            <p class="error">Error: <?php echo $signupError; ?></p>
        <?php endif; ?>
        <form action="signup.php" method="POST">
            <input type="text" name="signup_username" placeholder="Username" required>
            <input type="password" name="signup_password" placeholder="Password" required>
            <button type="submit">Sign Up</button>
        </form>
    </div>
</body>
</html>
