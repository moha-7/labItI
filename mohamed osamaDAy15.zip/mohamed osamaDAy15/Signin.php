<?php
session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "ccit";

// Create a database connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signin_username"]) && isset($_POST["signin_password"])) {
    $username = $_POST["signin_username"];
    $password = $_POST["signin_password"];

    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            setcookie("username", $username, time() + 3600, "/");
            header("Location: welcome.php?message=Welcome, $username!");
        } else {
            $signinError = "Invalid password.";
        }
    } else {
        $signinError = "User not found.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign In</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Sign In</h2>
        <?php if (isset($signinError)) : ?>
            <p class="error"><?php echo $signinError; ?></p>
        <?php endif; ?>
        <form action="signin.php" method="POST">
            <input type="text" name="signin_username" placeholder="Username" required>
            <input type="password" name="signin_password" placeholder="Password" required>
            <button type="submit">Sign In</button>
        </form>
    </div>
</body>
</html>
