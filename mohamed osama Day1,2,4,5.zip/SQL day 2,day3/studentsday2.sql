

-- 1. Create a function to calculate the number of students who get a grade less than 80 in a certain exam (course ID will be sent as a parameter):


DROP FUNCTION IF EXISTS count_students_below_80;

DELIMITER //

CREATE FUNCTION count_students_below_80(course_id_param INT) RETURNS INT
BEGIN
    DECLARE student_count INT;

    SELECT COUNT(*) INTO student_count
    FROM students_courses
    WHERE course_id = course_id_param AND grades < 80;

    RETURN student_count;
END
//

DELIMITER ;


SELECT count_students_below_80(2) AS students_below_80;


-- 2. Create a stored procedure to display the names of the absent students of a certain course (Absent means they have no grades):


DROP PROCEDURE IF EXISTS GetAbsentStudents;

DELIMITER //

CREATE PROCEDURE GetAbsentStudents(course_id_param INT)
BEGIN
    SELECT students.first_name
    FROM students
    LEFT JOIN students_courses sc ON students.student_id = sc.student_id
    WHERE sc.course_id = course_id_param AND sc.grades IS NULL;
END
//

DELIMITER ;

-- Example usage:
CALL GetAbsentStudents(2);


-- 3. Create a stored procedure to calculate the average grades for a certain course:


DELIMITER $$

CREATE PROCEDURE calculate_average_grades(course_id INT)
BEGIN
    SELECT course_id, AVG(grades) AS average_grade
    FROM students_courses
    WHERE course_id = course_id
    GROUP BY course_id;
END
$$

DELIMITER ;


-- 4. Create a trigger to keep track of changes (updates) of the grades in the students_courses table and create a changes table to store these changes:


-- Create the changes_table
CREATE TABLE changes_table (
    id INT PRIMARY KEY,
    user VARCHAR(30),
    action VARCHAR(40),
    old_grade INT,
    new_grade INT,
    change_date DATE
);

DELIMITER //

CREATE TRIGGER track_grade_changes
AFTER UPDATE ON students_courses
FOR EACH ROW
BEGIN
    IF NEW.grades <> OLD.grades THEN
        INSERT INTO changes_table (user, action, old_grade, new_grade, change_date)
        VALUES (USER(), 'Update', OLD.grades, NEW.grades, CURDATE());
    END IF;
END;
//

DELIMITER ;


-- 5. Create an event to delete old logs from the changes_table every 5 minutes:


CREATE EVENT delete_old_logs_event
ON SCHEDULE EVERY 5 MINUTE
DO
    DELETE FROM changes_table
    WHERE change_date < NOW() - INTERVAL 7 DAY;


