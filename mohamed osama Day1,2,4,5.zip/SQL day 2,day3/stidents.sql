

-- 1. Display the full name (first, last) of the student with their grade categorized as Excellent, Very Good, Good, Pass, or Failed:

SELECT CONCAT(first_name, ' ', last_name) AS full_name, 
       CASE 
           WHEN grades > 85 THEN 'Excellent'
           WHEN grades BETWEEN 75 AND 85 THEN 'Very Good'
           WHEN grades BETWEEN 65 AND 75 THEN 'Good'
           WHEN grades BETWEEN 55 AND 65 THEN 'Pass'
           ELSE 'Failed'
       END AS grade
FROM students s
INNER JOIN students_courses sc ON s.student_id = sc.student_id;


-- 2. Display the capitalized last name and the grade, using the `IFNULL` function to display "absent" if there's no grade:

SELECT UPPER(last_name) AS last_name, IFNULL(grades, 'absent') AS grade
FROM students s
LEFT JOIN students_courses sc ON s.student_id = sc.student_id;

-- 3. Display students' names, course names, and their grades:


SELECT CONCAT(first_name, ' ', last_name) AS fullname, course_name, grades
FROM students s
INNER JOIN students_courses sc ON s.student_id = sc.student_id
INNER JOIN courses c ON c.course_id = sc.course_id;


-- 4. For each course, display the course name, minimum grade, maximum grade, average grade, and the number of attended students:


SELECT c.course_name, 
       MIN(sc.grades) AS min_grade, 
       MAX(sc.grades) AS max_grade, 
       AVG(sc.grades) AS average_grade, 
       COUNT(DISTINCT sc.student_id) AS attended_students
FROM courses c
LEFT JOIN students_courses sc ON c.course_id = sc.course_id
GROUP BY c.course_name;


