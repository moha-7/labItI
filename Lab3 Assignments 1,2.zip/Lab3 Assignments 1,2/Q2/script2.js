document.addEventListener("DOMContentLoaded", function() {
    const taskInput = document.getElementById("taskInput");
    const addBtn = document.getElementById("addBtn");
    const taskList = document.getElementById("taskList");

    addBtn.addEventListener("click", function() {
        const taskName = taskInput.value.trim();

        if (taskName !== "") {
            const taskItem = document.createElement("li");
            taskItem.className = "task";
            taskItem.innerHTML = `
                <span>${taskName}</span>
                <button class="done-btn">Done</button>
                <button class="delete-btn">Delete</button>
            `;

            taskList.appendChild(taskItem);
            taskInput.value = "";

            const doneBtn = taskItem.querySelector(".done-btn");
            const deleteBtn = taskItem.querySelector(".delete-btn");

            doneBtn.addEventListener("click", function() {
                taskItem.querySelector("span").classList.toggle("done");
            });

            deleteBtn.addEventListener("click", function() {
                taskList.removeChild(taskItem);
            });
        }
    });
});