document.addEventListener("DOMContentLoaded", function() {
    const loginBtn = document.getElementById("loginBtn");
    const message = document.getElementById("message");

    loginBtn.addEventListener("click", function() {
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        const login = {
            username: username,
            password: password
        };

        if (login.username === "admin" && login.password === "123") {
            message.textContent = "Welcome";
        } else {
            message.textContent = "Not registered";
        }
    });
});