<!DOCTYPE html>
<html>
<head>
    <title>Application Form for AAST</title>
    <style>
        .container {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
        }

        label, input, select {
            margin-bottom: 10px;
            display: inline-block;;
        }

        input[type="submit"] {
            margin-top: 10px;
        }

        .error {
            color: red;
        }
        .label {
            display: inline-block;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Application Form</h2>
        <?php
        $nameErr = $emailErr = $groupErr = $classErr = $genderErr = $coursesErr = $agreeErr = "";

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["name"])) {
                $nameErr = "Name is required";
            }

            if (empty($_POST["email"])) {
                $emailErr = "Email is required";
            } elseif (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
                $emailErr = "Invalid email format";
            }

            if (empty($_POST["group"])) {
                $groupErr = "Group is required";
            }

            if (empty($_POST["class"])) {
                $classErr = "At least one class must be selected";
            }

            if (empty($_POST["gender"])) {
                $genderErr = "Gender is required";
            }

            if (empty($_POST["courses"])) {
                $coursesErr = "At least one course must be selected";
            }

            if (empty($_POST["agree"])) {
                $agreeErr = "You must agree to continue";
            }

            if (empty($nameErr) && empty($emailErr) && empty($groupErr) && empty($classErr) && empty($genderErr) && empty($coursesErr) && empty($agreeErr)) {
                echo "<h2>Form Submission Result</h2>";
                echo "Name: " . $_POST["name"] . "<br>";
                echo "Email: " . $_POST["email"] . "<br>";
                echo "Group: " . $_POST["group"] . "<br>";
                echo "Class Details: " . implode(", ", $_POST["class"]) . "<br>";
                echo "Gender: " . $_POST["gender"] . "<br>";
                echo "Selected Courses: " . implode(", ", $_POST["courses"]) . "<br>";
            }
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="name">Name:</label>
            <input type="text" name="name" required>
            <span class="error"><?php echo $nameErr; ?></span><br>

            <label for="email">Email:</label>
            <input type="email" name="email" required>
            <span class="error"><?php echo $emailErr; ?></span><br>

            <label for="group">Group:</label>
            <input type="text" name="group" required>
            <span class="error"><?php echo $groupErr; ?></span><br>

            <label for="class">Class Details:</label>
            <select name="class[]" multiple required>
                <option value="class1">Class 1</option>
                <option value="class2">Class 2</option>
                <option value="class3">Class 3</option>
            </select>
            <span class="error"><?php echo $classErr; ?></span><br>

            <label>Gender:</label>
            <input type="radio" name="gender" value="male" required>Male
            <input type="radio" name="gender" value="female" required>Female
            <span class="error"><?php echo $genderErr; ?></span><br>

            <label for="courses">Select Courses:</label>
            <select name="courses[]" multiple required>
                <option value="Html">Html</option>
                <option value="CSS">Css</option>
                <option value="JavaScript">JavaScript</option>
            </select>
            <span class="error"><?php echo $coursesErr; ?></span><br>

            <label for="agree">Agree:</label>
            <input type="checkbox" name="agree" required>
            <span class="error"><?php echo $agreeErr; ?></span><br>

            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
