function calculateArea() {
    var shape = document.getElementById("shape").value;
    var area;

    switch (shape) {
        case "circle":
            var radius = parseFloat(prompt("Enter the radius:"));
            area = Math.PI * Math.pow(radius, 2);
            break;
        case "triangle":
            var base = parseFloat(prompt("Enter the base:"));
            var height = parseFloat(prompt("Enter the height:"));
            area = 0.5 * base * height;
            break;
        case "square":
            var side = parseFloat(prompt("Enter the length of side:"));
            area = Math.pow(side, 2);
            break;
        case "rectangle":
            var length = parseFloat(prompt("Enter the length:"));
            var width = parseFloat(prompt("Enter the width:"));
            area = length * width;
            break;
        case "parallelogram":
            var base = parseFloat(prompt("Enter the base:"));
            var height = parseFloat(prompt("Enter the vertical height:"));
            area = base * height;
            break;
        case "trapezium":
            var a = parseFloat(prompt("Enter the length of first parallel side:"));
            var b = parseFloat(prompt("Enter the length of second parallel side:"));
            var height = parseFloat(prompt("Enter the height:"));
            area = 0.5 * (a + b) * height;
            break;
        case "ellipse":
            var a = parseFloat(prompt("Enter half of the minor axis:"));
            var b = parseFloat(prompt("Enter half of the major axis:"));
            area = Math.PI * a * b;
            break;
        default:
            area = "Invalid shape name";
            break;
    }

    var resultDiv = document.getElementById("result");
    resultDiv.innerHTML = `<p>Area of the ${shape}: ${area}</p>`;
}