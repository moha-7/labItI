<?php
// Task 1: Show phpinfo on browser
phpinfo();

// Task 2: Define a constant for website name
define('WEBSITE_NAME', 'MyWebsite');

// Task 3: Display server info and current script's filename/path
$serverName = $_SERVER['SERVER_NAME'];
$serverAddress = $_SERVER['SERVER_ADDR'];
$serverPort = $_SERVER['SERVER_PORT'];
$currentScriptFilename = $_SERVER['SCRIPT_FILENAME'];
$currentScriptPath = $_SERVER['SCRIPT_NAME'];

echo "Website Name: " . WEBSITE_NAME . "<br>";
echo "Server Name: $serverName <br>";
echo "Server Address: $serverAddress <br>";
echo "Server Port: $serverPort <br>";
echo "Current Script Filename: $currentScriptFilename <br>";
echo "Current Script Path: $currentScriptPath <br>";

// Task 4: Determine your brother's age category using switch case
$brotherAge = 10;
switch ($brotherAge) {
    case ($brotherAge < 5):
        echo "Brother should stay at home.";
        break;
    case 5:
        echo "Brother should go to Kindergarten.";
        break;
    case ($brotherAge >= 6 && $brotherAge <= 12):
        echo "Brother should go to grade: $brotherAge";
        break;
    default:
        echo "Brother's age doesn't fit into any category.";
}
?>
